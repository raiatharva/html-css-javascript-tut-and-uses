numbers = ["3", "45", "65"]

for i in range(len(numbers)):
  numbers[i] = int(numbers[i])

numbers[2] = numbers[2] + 1
print(numbers[2])