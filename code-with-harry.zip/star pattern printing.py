# print("Enter number here")
# num = int(input())
# for i in range(1, num+1):
#    for j in range(1 ,i+1):
#       print("*", end="")
#    print()

print("Enter number here")
num = int(input())
for i in range(num,0,-1):
   for j in range(0 ,i):
      print("*", end="")
   print()