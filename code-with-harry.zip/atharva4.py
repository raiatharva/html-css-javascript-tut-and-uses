def printath(string):
  return f"hello everyone my name is atharva rai {string}"

def add(num1, num2):
  return num1 + num2 + 5

print("and the content is from", __name__)
if __name__=='__main__':
  print(printath("hain"))
  o = add(4, 6)
  print(o)