a = "this is how we can use import"
b = int(input("enter number 1 here"))
c = int(input("enter number 2 here"))
def add():
   sum = (int(b)+int(c))
   print("Sum of two numbers is = ", sum)

def printthis(str):
  print(f"we are using the import here to copy our{str}")