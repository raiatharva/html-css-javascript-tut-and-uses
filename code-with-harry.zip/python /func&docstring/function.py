a = 7
b = 8
c = sum((a, b))#built in function
#we can use here tuple or list as they are iterable.
print(c)

#user-defined function
def function_1(a, b):
  print("hello, it's me", a+b)
function_1(5, 7)

def function_2(a, b):
  """this is func use to calculate average"""
  average = (a+b)/2
  print(average)
  return average
v = function_2(5, 7)
print(v)
print(function_2.__doc__)#used to read docstring