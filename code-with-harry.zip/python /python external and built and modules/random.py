import random

random_number = random.randint(0,100)
print(random_number)

#2nd method to use random module
rand = random.random() *100
print(rand)

#3rd method to use random module when we give a list and tell random to pick random from it as following:-
list1 = ["hello", "hola!", "waka-waka!", "bonjour"]
choice = random.choice(list1)
print(choice)