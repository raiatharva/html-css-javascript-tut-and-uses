#Identity operator
a = True 
b = False

print(a is b)
print(a is not b)