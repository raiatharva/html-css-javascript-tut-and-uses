# Comparison operators
i = 5
print(i == 5)
print(i != 5)
print(i < 5)
print(i > 5)
print(i <= 5)
print(i >= 5)