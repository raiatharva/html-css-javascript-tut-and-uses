# Assignment operators
x = 5
print(x)
x-=7
x/=7
x%=7
x*=7
x += 7
print(x)