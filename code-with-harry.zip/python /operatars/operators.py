"""
Operators in python:-
1. Arithemetic operators 
2. assignment operatprs
3. comparision operators
4. logical operators
7. Identity operator
5. membership operators
6. bitwise operators 
"""