# Arithmetic operators
print("5+6 is", 5+6)
print("5-6 is", 5-6)
print("5*6 is", 5*6)
print("5/6 is", 5/6)
print("5//6 is", 5//6)
print("5%6 is", 5%6)
print("5**6 is", 5**6)