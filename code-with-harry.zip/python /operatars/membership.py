#Membership operator
list1 = [45, 46, 23, 56, 98, 75]

print(5 in list1)
print(5 not in list1)