list1 = ["atharva", "ashu", "ritesh", "nishu", "paro"]
for item in list1:
  print(item)

"""
list1 = [["atharva", 6], ["ashu", 5], ["ritesh", 8], ["nishu", 9], ["paro", 23]]
for item, lollypop in list1:
  print(item, "and lolly is", lollypop)
"""

list1 = [["atharva", 6], ["ashu", 5], ["ritesh", 8], ["nishu", 9], ["paro", 23]]
dict1 = dict(list1)
print(dict1)
for items, lollypop in dict1.items():
  print(items, "and lolly is", lollypop)

list2 = [int, float, str, "atharva", 1, 2 ,6 , 8, 89, 3774, 87, 233]

for item in list2:
  if str(item).isnumeric() and item>=6:
    print(item)
