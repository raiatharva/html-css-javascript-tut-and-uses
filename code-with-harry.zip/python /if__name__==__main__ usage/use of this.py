import atharva4

print(atharva4.add(5, 4))

# the main content of this file is in atharva4.py