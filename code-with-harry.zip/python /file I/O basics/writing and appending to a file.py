# writing to a file 
f = open("atharva.txt", "w")
f.write("atharva is a very intalligent boy")
f.close()

# appending to a file
f = open("atharva2.txt", "a")
f.write("atharva is a very intalligent boy\n")
f.close()
# to show how many character you have entered in your file
f = open("atharva2.txt", "a")
a = f.write("atharva is a very intalligent boy\n")
print(a)
f.close()

f = open("atharva.txt", "r+")#to read and write in one mode
print(f.read())
f.write("Thank you")
f.close()