# File IO
"""
"r" = Open file for reading - default
'w' = open a file for writing
"x" = Creates file if not exists
"a" = Add more content to a file / append to a File
"t" = text Mode - default
"b" = binary mode
"+" = read and write
"""