with open("atharva2.txt") as f:
  print(f.readlines())#1st way to print"don' use both of them"
  a = f.readlines()#2nd way to print 
  print(a)

# f = open("atharva2.txt", "rt")
# print(f.readlines())
# f.close()