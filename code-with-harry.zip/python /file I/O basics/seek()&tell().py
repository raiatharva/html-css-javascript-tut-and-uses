f = open("atharva2.txt")
print(f.tell())
print(f.readline())
print(f.tell())
f.seek(0)
print(f.readline())
print(f.tell())
f.close()

"""
f.tell() function hume ye btata hain ki humne kitne character print kar diye hain ek line me
f.seek() funtion vapas se utne hi charcter se print krega jitna hum usko batayenge for eg.=f.seek(10) yaha maine ye btaya hain ki 10 character se print karo
"""