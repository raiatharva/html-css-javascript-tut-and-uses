# open a file and read it
f = open("atharva.txt")
content  = f.read()
print(content)

f.close()

# to open and read a file by "r" function
f = open("atharva.txt", "r")
f = open("atharva.txt", "rb")
f = open("atharva.txt", "rt")
content  = f.read()
print(content)

f.close()

f = open("atharva.txt", "rt")
content  = f.read(3)
print(content)

content  = f.read(3)
print(content)

f.close()

f = open("atharva.txt", "rt")
# content  = f.read()

for line in f:
  print(line)
  print(line, end="")

f.close()

f = open("atharva.txt", "rt")
content  = f.read()

for line in content:
  print(line)

f.close()
# readline
f = open("atharva.txt", "rt")
print(f.readline())
print(f.readlines())
