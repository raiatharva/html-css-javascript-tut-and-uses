import math
# F Strings
# normal method people do like 
me = "Atharva"
a = "This is %s"%me
print(a)

me = "Atharva"
aa = 5
a = "this is {} {}"
a = "this is {1} {0}"
b = a.format(me, aa)
print(b)

# best way to do string formatting is:
a = f"this is {aa} {me}"
print(a)