"""
ek chiz jo alag alg rup dharad krna
"""
print(5 + 6)
print("5" + "6")