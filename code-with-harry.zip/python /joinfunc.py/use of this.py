lsi = ["atharva", "rai", 'ritesh', 'rai', 'ashu', 'rai']

a = ", ".join(lsi)
print(a, "other wwe stars")