var1 = 6
var2 = 4
var3 = int(input())
if var3>var2:
  print("Greater")
else:
  print("Lesser")

  l = [4, 6, 7, 8]
if 4 in l:
 print("Yes, it is in the list")
 l = [4, 6, 7, 8]
print(4 in l)
if 4 in l:
 print("Yes, it is in the list")


l = [4, 6, 7, 8]
print(4 not in l)
if 4 not in l:
 print("Yes, it is in the list")