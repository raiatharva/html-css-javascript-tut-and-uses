var1 = 6
var2 = 4
var3 = int(input())
if var3>var2:
  print("Greater")
elif var3==var2:
  print("Equal")
else:
  print("Lesser")