print("Enter number 1 here")
num1 = input()
print("Enter number 2 here")
num2 = input()
try:
  print("sum of these two numbers is", int(num1)+int(num2))
except Exception as e:
  print(e)
print("hey atharva here")