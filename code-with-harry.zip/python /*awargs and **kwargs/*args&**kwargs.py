# def function_name_print(a, b, c, d):
  # print(a, b, c, d)
# function_name_print("Atharva", "ashu", "ritesh", "harry")

 # *args(we can add many names by using this without traditionally doing it)
# def funargs(*args):
#   print(args[0])
# ath = ["Atharva", "ashu", "ritesh", "harry"]
# funargs(*ath)

def funargs(normal, *args, **kwargs):
  print(normal)
  for item in args:
    print(item)
  print("here i am introducing our heroes")
  for key, value in kwargs.items():
    print(f"{key} is a {value}")

ath = ["Atharva", "ashu", "ritesh", "harry"]
normal = "the list of students are:-"
kw = {"rohan":"monitor", "atharva":"programmer"}
funargs(normal, *ath, **kw)