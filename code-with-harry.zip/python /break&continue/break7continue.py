
i = 0
while(True):
  i = i+ 1
  if i+1 <5:
    continue
  print(i+1, end=" ")
  if(i==44):
    break#stop the loop
  i = i+ 1
  #


while (True):
  inp = int(input("Enter a number"))
  if inp>100:
    print("Congrats you entered a number greater than 100")
    break
  else:
     continue