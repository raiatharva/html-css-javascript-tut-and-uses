d2 = {"atharva":"burger", "ashu":"chai", "ritesh":"khana"}
print(d2["atharva"])

# we can also add the vslue as dictionary 
d2 = {"atharva":"burger", "ashu":"chai", "ritesh":"khana", "mata":{"b":"chai", "l":"khana", "d":"khanana"}}
print(d2["mata"])
#we can also point out the (b,l,d)
print(d2["mata"] ["d"])
#
d2["shubham"] = "chicken"
d2[13]="hamburger"
del d2[atharva]
print(d2)
#
d3 = d2
del d3["atharva"]
print(d2)