d2 = {"atharva":"burger", "ashu":"chai", "ritesh":"khana", "mata":{"b":"chai", "l":"khana", "d":"khanana"}}

print(d2.copy())

print(d2.get("atharva"))

print(d2.keys())

print(d2.clear())

print(d2.items())

d2.update({"abhinav":"dairy milk"})
print(d2)