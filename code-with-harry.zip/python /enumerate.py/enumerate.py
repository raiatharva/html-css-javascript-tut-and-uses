l1 = ["bhindi", "aloo", "karela", "tomato"]

#normal method
i = 1
for item in l1:
  if i%2!=0:
    print(f"Hello please buy these {item}")
  i+=1
#enumertae function
for index, item in enumerate(l1):
  if index%2!=0:
    print(f"hey can you buy these{item}")