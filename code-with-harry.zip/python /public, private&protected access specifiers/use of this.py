# public - 
# protected - 
# private - 
class Employee:
  no_of_leaves = 8
  _protec = 9 #protected can be access by class derived from this can use it as - see line no 26
  __private = 98 #private cannot be access other than this class and it used in other way see at line no 28

  def printdetails(self):
   return f"Name is {self.name}.Salary is {self.salary} and Role is {self.role}"
  def __init__(self, name, salary, role):
    self.name = name
    self.salary = salary
    self.role = role
  @classmethod
  def change_leaves(cls, newleaves):
    cls.no_of_leaves = newleaves
  @classmethod
  def from_str(cls, string):
    return cls(*string.split("-"))
  @staticmethod
  def printgood(string):
    print("this is good",  string)#gives space
    print("this is good" +  string)#optional
emp = Employee("atharva", 45454, "programmer")
print(emp._protec)
print(emp._Employee__private)