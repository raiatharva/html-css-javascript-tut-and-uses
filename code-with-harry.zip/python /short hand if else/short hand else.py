a = int(input("enter a\n"))
b = int(input("enter b\n"))

if a>b: print("A B se bada hain")