class Employee:
  no_of_leaves = 8
  pass

atharva = Employee()
harry = Employee()

atharva.name = "Atharva"
atharva.salary = 20000
atharva.role =  'software engineer'
harry.name = "harry"
harry.salary = 24000
harry.role = 'product manager'
# print(atharva.salary)
# print(atharva.no_of_leaves)
# print(Employee.no_of_leaves)
# print(harry.__dict__)
# harry.no_of_leaves = 9
# print(harry.no_of_leaves)
# print(harry.__dict__)
# print(Employee.no_of_leaves)

print(Employee.no_of_leaves)
print(Employee.__dict__)
Employee.no_of_leaves = 9
print(Employee.__dict__)
print(Employee.no_of_leaves)