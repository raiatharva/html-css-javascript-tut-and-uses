class Employee:
  no_of_leaves = 8

  def printdetails(self):
   return f"Name is {self.name}.Salary is {self.salary} and Role is {self.role}"
  def __init__(self, name, salary, role):
    self.name = name
    self.salary = salary
    self.role = role
  @classmethod
  def change_leaves(cls, newleaves):
    cls.no_of_leaves = newleaves
  @classmethod
  def from_str(cls, string):
    return cls(*string.split("-"))
  @staticmethod
  def printgood(string):
    print("this is good",  string)#gives space
    print("this is good" +  string)#optional

class player:
  no_of_games = 4
  
  def __init__(self, name, game):
    self.name = name
    self.game = game
  def printdetails(self):
    return f"the name is {self.name} and game is{self.game}"

class CoolProgrammer(Employee, player):
  language = "python"
  def printlanguage(self):
    print(self.language)
atharva = Employee("Atharva", 20000, "software engineer")
harry = Employee("Harry", 4500, "instructor")
shubham = player("Shubham", ["football"])
karan = CoolProgrammer("karan", 9898, "CoolProgrammer")
prints = karan.printdetails()
print(prints)
karan.printlanguage()