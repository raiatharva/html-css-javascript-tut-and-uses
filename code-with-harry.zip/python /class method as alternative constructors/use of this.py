class Employee:
  no_of_leaves = 8

  def printdetails(self):
   return f"Name is {self.name}.Salary is {self.salary} and Role is {self.role}"

atharva = Employee()
harry = Employee()

atharva.name = "Atharva"
atharva.salary = 20000
atharva.role =  'software engineer'
harry.name = "harry"
harry.salary = 24000
harry.role = 'product manager'
# print(harry.printdetails())

# use of intit
class Employee:
  no_of_leaves = 8

  def printdetails(self):
   return f"Name is {self.name}.Salary is {self.salary} and Role is {self.role}"
  def __init__(self, name, salary, role):
    self.name = name
    self.salary = salary
    self.role = role
  @classmethod
  def change_leaves(cls, newleaves):
    cls.no_of_leaves = newleaves
  @classmethod
  def from_str(cls, string):
    # params = string.split("-")(usefull but bigger)
    # return cls(params[0], params[1], params[2])
    return cls(*string.split("-"))

atharva = Employee("Atharva", 20000, "software engineer")
harry = Employee("Harry", 4500, "instructor")
karan = Employee.from_str("karan-6556-jumiorengineer")
print(karan.name)