class Employee:
  no_of_leaves = 8

  def printdetails(self):
   return f"Name is {self.name}.Salary is {self.salary} and Role is {self.role}"
  def __init__(self, name, salary, role):
    self.name = name
    self.salary = salary
    self.role = role
  @classmethod
  def change_leaves(cls, newleaves):
    cls.no_of_leaves = newleaves
  @classmethod
  def from_str(cls, string):
    return cls(*string.split("-"))
  @staticmethod
  def printgood(string):
    print("this is good",  string)#gives space
    print("this is good" +  string)#optional

class programmer(Employee):
  def __init__(self, name, salary, role, language):
    self.name = name
    self.salary = salary
    self.role = role
    self.language = language
  def printprog(self):
    return f"the programmer name is {self.name}. salary is{self.salary}. role is {self.role}. lnaguage known are {self.language}"
atharva = Employee("Atharva", 20000, "software engineer")
harry = Employee("Harry", 4500, "instructor")

shubham = programmer("Shubham", 6767, "programmer", ["python"])
manthan = programmer("Shubham", 5767, "programmer", ["python"])
print(manthan.printprog())