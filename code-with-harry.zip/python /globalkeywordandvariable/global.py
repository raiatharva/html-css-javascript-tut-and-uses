l = 10 # Global variable
def function1(n):
  l = 5 # Local variable
  m = 8
  print(l, m)
  print(n, "I have already printed a function")

function1("This is me")
print(l)

# global keyword
l = 10 # Global variable
def function1(n):
  # l = 5 # Local variable
  m = 8
  global l
  l = l + m
  print(l, m)
  print(n, "I have already printed a function")

function1("This is me")
print(l)