# nested function
x = 89
def atharva():
  x= 56
  def harry():
    global x
    x = 88
  print("before calling harry ()", x)
  harry()
  print("after calling harry()", x)

atharva()
print(x)