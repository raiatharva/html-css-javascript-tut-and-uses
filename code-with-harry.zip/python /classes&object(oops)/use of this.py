class Student:
  pass

atharva = Student()
harry = Student()

atharva.name = "atharva"
atharva.std = 8
atharva.section = 'a'
# print(atharva.name)
# print(atharva,harry)
