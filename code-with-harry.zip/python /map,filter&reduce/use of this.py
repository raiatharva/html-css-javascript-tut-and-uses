numbers = ["3", "45", "65"]

numbers = list(map(int, numbers))

numbers[2] = numbers[2] + 1
# print(numbers[2])

num = [2,3,45,7,8,98,6,5]
square = list(map(lambda x: x*x, num))
# print(square)

def square(a):
  return a*a
def cube(a):
  return a*a*a
func = [square, cube]
for i in range(5):
  val = list(map(lambda x:x(i), func))
  # print(val)

"""filter"""
list_1 = [1,2,3,4,5,6,7,8,9]
def is_greater_5(num):
  return num>5

gr_than_5 = list(filter(is_greater_5, list_1))
# print(gr_than_5)

#----------------reduce------------------
from functools import reduce
list2 = [1,2,3,4,5,6,7]
num = reduce(lambda x,y:x+y, list2)
# print(num)