import atharva3
print(atharva3.a)

from atharva3 import a
print(a)

import atharva3

atharva3.add()
atharva3.printthis("import")