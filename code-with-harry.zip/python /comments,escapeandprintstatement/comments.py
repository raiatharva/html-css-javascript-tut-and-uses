#this is single line comment
"""
this is a 
multiline 
comment
"""
print("hello everyone this is the content", end=", ")
print("of the folder")