print("hey everyone my name is \n Atharva Rai \t")

"""
here :-
\n = newline
\t = creates tab space
"""