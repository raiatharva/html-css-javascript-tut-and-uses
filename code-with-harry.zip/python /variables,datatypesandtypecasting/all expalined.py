var1 = "hello everyone this is container"
var4 = "Atharva Rai"
var2 = 4
var3 = 36.7
print(type(var3))
print(var2 + var3)
#if we want to add str values as int value then:-
varr1 = "34"
varr2 = "64"
print(int(varr1) + int(varr2))
#if we wanna print 100 times any sentence:-
print(100 * ("Hello evryone this is Atharva\n"))
print(100 * str(int(varr1)+int(varr2)))#if we wanna print any integer 100 times