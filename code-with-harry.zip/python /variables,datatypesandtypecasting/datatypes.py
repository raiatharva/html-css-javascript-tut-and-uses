var4 = "Atharva Rai"
var2 = 4
var3 = 36.7
"""
int()
str()
float()
one more datatype id there and called boolean(True,false)
"""