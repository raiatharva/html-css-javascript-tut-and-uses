s = set()
s_from_list = set([1, 2, 3, 4, 5])
print(s_from_list)
print(type(s_from_list))

#or
l = [1, 2, 3, 4, 5, 6]
s_from_listd = set(l)
print(s_from_listd)

s = set()
#how to add value un set
s.add(1)
s.add(2)
s1 = s.union({1, 2, 3})
s1 = s.intersection({1, 2, 3})
s1 = {4, 6}
print(s.isdisjoint(s1))
print(s, s1)
print(len(s))
print(max(s))
print(min(s))

s = set()
#how to add value un set
s.add(1)
s.add(2)
s.remove(2)
print(s)