class Dad:
  basketball =1

class Son(Dad):
  dance =4

  def isdance(self):
    return f"yes i dance {self.dance} many times a day"

class Grandson(Son):
  dance =9
  def isdance(self):
    return f"absolutely yes i dance {self.dance} times a day"


papa = Dad()
beta = Son()
grandson = Grandson()
# print(grandson.isdance())
# print(grandson.basketball)