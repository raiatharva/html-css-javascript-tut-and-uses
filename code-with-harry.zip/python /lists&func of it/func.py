numbers = [2, 4, 5, 78, 7, 8]
numbers.sort()
numbers.reverse()
numbers.append(4)
numbers.insert(3, 45)#it will pritn 45 on 3 rd place of list starting from 0
numbers.remove(78)
print(numbers)