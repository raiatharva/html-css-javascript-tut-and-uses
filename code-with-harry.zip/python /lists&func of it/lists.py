grocery = ["sanitizer", "aloo", "bhindi", "lauki", "56"]
print(grocery)
print(grocery[2])

numbers = [2, 4, 5, 78, 7, 8]
print(numbers[4])
print(numbers[0:2])
print(numbers[1:4])
print(numbers[:-2])
print(numbers[5:1:-2])

print(len(numbers))
print(max(numbers))
print(min(numbers))
numbers[1] = 34

"""
there aRE SOME THINGS which are mutable and immutable:-
immutable = lists
mutable = tuple
"""