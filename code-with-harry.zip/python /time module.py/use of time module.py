import time
#to see the programe execution time
initial = time.time()
print(initial)
k=0
while(k<45):
  print('this is atharva rai')
  k+=1
for i in range(45):
  print("This is atharva rai")

#to see the the execution itme of while and for loop 
initial = time.time()
k=0
while(k<45):
  print('this is atharva rai')
  time.sleep(2)
  k+=1
print("while loop ran in", time.time() - initial, "Seconds")
initial2 = time.time()
for i in range(45):
  print("This is atharva rai")
print("for loop ran in", time.time() - initial2, "Seconds")
#to print local time
localtime = time.asctime(time.localtime(time.time()))
print(localtime)