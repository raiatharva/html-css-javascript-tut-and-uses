class Employee:
  no_of_leaves = 8

  def printdetails(self):
   return f"Name is {self.name}.Salary is {self.salary} and Role is {self.role}"

atharva = Employee()
harry = Employee()

atharva.name = "Atharva"
atharva.salary = 20000
atharva.role =  'software engineer'
harry.name = "harry"
harry.salary = 24000
harry.role = 'product manager'
# print(harry.printdetails())

# use of intit
class Employee:
  no_of_leaves = 8

  def printdetails(self):
   return f"Name is {self.name}.Salary is {self.salary} and Role is {self.role}"
  def __init__(self, name, salary, role):
    self.name = name
    self.salry = salary
    self.role = role

atharva = Employee("Atharva", 20000, "software engineer")
# harry = Employee()

# atharva.name = "Atharva"
# atharva.salary = 20000
# atharva.role =  'software engineer'
# harry.name = "harry"
# harry.salary = 24000
# harry.role = 'product manager'
print(atharva.name)