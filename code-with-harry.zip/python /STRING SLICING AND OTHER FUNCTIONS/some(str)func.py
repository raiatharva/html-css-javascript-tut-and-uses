mystr = "atharva is a good boy"
#it will print false as spaces are there
print(mystr.isalnum())
#it will also print false as spaces are there
print(mystr.isalpha())
print(mystr.count("o"))
print(mystr.endswith("boy"))
print(mystr.capitalize())
print(mystr.find("is"))
print(mystr.upper())
print(mystr.lower())
print(mystr.replace("is","are"))